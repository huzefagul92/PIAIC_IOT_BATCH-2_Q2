
use line_formula::line_dis_formula;

fn main() {

    line_dis_formula();
    
}